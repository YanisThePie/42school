require 'test_helper'

class PointsofsaleHelperTest < ActionView::TestCase
end

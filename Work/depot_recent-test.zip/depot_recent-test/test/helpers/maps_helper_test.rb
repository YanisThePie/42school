require 'test_helper'

class MapsHelperTest < ActionView::TestCase
end

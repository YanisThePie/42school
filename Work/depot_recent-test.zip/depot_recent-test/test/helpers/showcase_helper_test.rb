require 'test_helper'

class ShowcaseHelperTest < ActionView::TestCase
end

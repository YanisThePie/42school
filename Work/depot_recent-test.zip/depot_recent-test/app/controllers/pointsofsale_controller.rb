class PointsofsaleController < ApplicationController
  skip_before_action :admin_only
  skip_before_action :authorize
  def index
    @maps = Map.order(:title)
  end
end

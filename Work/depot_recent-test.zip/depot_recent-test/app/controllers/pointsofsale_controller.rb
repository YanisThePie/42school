class PointsofsaleController < ApplicationController
  def index
    @maps = Map.order(:title)
  end
end

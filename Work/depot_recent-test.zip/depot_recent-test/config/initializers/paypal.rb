PayPal::Recurring.configure do |config|
  config.sandbox = true
  config.username = "yanisisma-facilitator_api1.msn.com"
  config.password = "Y8DDP3T364KXX2BW"
  config.signature = "AFcWxV21C7fd0v3bYYYRCpSSRl31AzqMv27pRTjHR6uXBKKnK58WpYpr"
end

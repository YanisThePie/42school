# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Depot::Application.config.secret_key_base = '8b070917bbf932ed22e4bbc76da16aaf27953c6b7a04bcfde6b670ba7a54f1f602eb41cce01baacf433f9a5d49358f70b108dd2f64e1746b5dc04e098a686c55'

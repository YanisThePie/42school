#encoding: utf-8
I18n.default_locale = :fr

LANGUAGES = [
  ['Français', 'fr'],
  ['English', 'en']
]

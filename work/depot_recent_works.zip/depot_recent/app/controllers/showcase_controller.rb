class ShowcaseController < ApplicationController
  skip_before_action :authorize
  def Home
  end
end

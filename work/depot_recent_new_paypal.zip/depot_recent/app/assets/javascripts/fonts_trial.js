(function() {
       var path = '//easy.myfonts.net/v2/js?sid=293573(font-family=Futura+Medium)&sid=293577(font-family=Futura+Light)&sid=293581(font-family=Futura+Condensed+Medium)&sid=293589(font-family=Futura+Book)&key=sHmvb6wPVU',
           protocol = ('https:' == document.location.protocol ? 'https:' : 'http:'),
           trial = document.createElement('script');
       trial.type = 'text/javascript';
       trial.async = true;
       trial.src = protocol + path;
       var head = document.getElementsByTagName("head")[0];
       head.appendChild(trial);
   })();
         (function() {
                 var path = '//easy.myfonts.net/v2/js?sid=211102(font-family=Didot+LT+Pro+Bold)&sid=218035(font-family=Didot+LT+Pro+Roman)&sid=255247(font-family=Didot+LT+Std+Bold+Italic)&sid=257210(font-family=Didot+LT+Std+Italic)&key=jOoEaFxLMf',
                     protocol = ('https:' == document.location.protocol ? 'https:' : 'http:'),
                     trial = document.createElement('script');
                 trial.type = 'text/javascript';
                 trial.async = true;
                 trial.src = protocol + path;
                 var head = document.getElementsByTagName("head")[0];
                 head.appendChild(trial);
             })();
